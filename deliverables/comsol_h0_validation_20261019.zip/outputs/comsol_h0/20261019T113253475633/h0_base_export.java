/*
 * h0_base_export.java
 */

import com.comsol.model.*;
import com.comsol.model.util.*;

/** Model exported on Oct 19 2026, 11:33 by COMSOL 6.3.0.290. */
public class h0_base_export {

  public static Model run() {
    Model model = ModelUtil.create("Model");

    model.label("H0 silicon thermal verification - base");

    model.modelPath("C:/Users/Lenovo/Desktop/codex/2027/outputs/comsol_h0/20261019T113253475633");

    model.param().set("Lx", "0.01[m]");
    model.param().set("Ly", "0.01[m]");
    model.param().set("Lz", "0.0001[m]");
    model.param().set("qSi", "5000000000[W/m^3]");
    model.param().set("hTop", "100000[W/(m^2*K)]");
    model.param().set("Tamb", "300[K]");
    model.param().set("Tref", "300[K]");
    model.param().set("dTtest", "10[K]");
    model.param().set("si_k", "130[W/(m*K)]");
    model.param().set("si_rho", "2329[kg/m^3]");
    model.param().set("si_cp", "702.30141691713186[J/(kg*K)]");
    model.param().set("si_E", "135000000000[Pa]");
    model.param().set("si_nu", "0.28000000000000003");
    model.param().set("si_alpha", "2.6000000000000001e-06[1/K]");
    model.param().set("cu_k", "400[W/(m*K)]");
    model.param().set("cu_rho", "8960[kg/m^3]");
    model.param().set("cu_cp", "390[J/(kg*K)]");
    model.param().set("cu_E", "120000000000[Pa]");
    model.param().set("cu_nu", "0.34000000000000002");
    model.param().set("cu_alpha", "1.6500000000000001e-05[1/K]");
    model.param().set("ox_k", "1.3999999999999999[W/(m*K)]");
    model.param().set("ox_rho", "2200[kg/m^3]");
    model.param().set("ox_cp", "730[J/(kg*K)]");
    model.param().set("ox_E", "70000000000[Pa]");
    model.param().set("ox_nu", "0.17000000000000001");
    model.param().set("ox_alpha", "4.9999999999999998e-07[1/K]");

    model.component().create("comp1", true);

    model.component("comp1").geom().create("geom1", 3);
    model.component("comp1").geom("geom1").lengthUnit("m");
    model.component("comp1").geom("geom1").create("blk1", "Block");
    model.component("comp1").geom("geom1").feature("blk1").set("size", new String[]{"Lx", "Ly", "Lz"});
    model.component("comp1").geom("geom1").feature("blk1").set("pos", new String[]{"0", "0", "0"});
    model.component("comp1").geom("geom1").run();

    model.component("comp1").selection().create("top", "Box");
    model.component("comp1").selection("top").set("entitydim", 2);
    model.component("comp1").selection("top").set("condition", "inside");
    model.component("comp1").selection("top").set("xmin", "-1e-8");
    model.component("comp1").selection("top").set("xmax", "Lx+1e-8");
    model.component("comp1").selection("top").set("ymin", "-1e-8");
    model.component("comp1").selection("top").set("ymax", "Ly+1e-8");
    model.component("comp1").selection("top").set("zmin", "Lz-1e-8");
    model.component("comp1").selection("top").set("zmax", "Lz+1e-8");
    model.component("comp1").selection().create("bottom", "Box");
    model.component("comp1").selection("bottom").set("entitydim", 2);
    model.component("comp1").selection("bottom").set("condition", "inside");
    model.component("comp1").selection("bottom").set("xmin", "-1e-8");
    model.component("comp1").selection("bottom").set("xmax", "Lx+1e-8");
    model.component("comp1").selection("bottom").set("ymin", "-1e-8");
    model.component("comp1").selection("bottom").set("ymax", "Ly+1e-8");
    model.component("comp1").selection("bottom").set("zmin", "0-1e-8");
    model.component("comp1").selection("bottom").set("zmax", "0+1e-8");
    model.component("comp1").selection().create("bottomEdges", "Box");
    model.component("comp1").selection("bottomEdges").set("entitydim", 1);
    model.component("comp1").selection("bottomEdges").set("condition", "inside");
    model.component("comp1").selection("bottomEdges").set("xmin", "-1e-8");
    model.component("comp1").selection("bottomEdges").set("xmax", "Lx+1e-8");
    model.component("comp1").selection("bottomEdges").set("ymin", "-1e-8");
    model.component("comp1").selection("bottomEdges").set("ymax", "Ly+1e-8");
    model.component("comp1").selection("bottomEdges").set("zmin", "0-1e-8");
    model.component("comp1").selection("bottomEdges").set("zmax", "0+1e-8");

    model.component("comp1").material().create("mat1", "Common");
    model.component("comp1").material("mat1").label("Constant silicon - independent synthetic fixture");
    model.component("comp1").material("mat1").selection().all();
    model.component("comp1").material("mat1").propertyGroup("def")
         .set("thermalconductivity", new String[]{"si_k", "0", "0", "0", "si_k", "0", "0", "0", "si_k"});
    model.component("comp1").material("mat1").propertyGroup("def").set("density", "si_rho");
    model.component("comp1").material("mat1").propertyGroup("def").set("heatcapacity", "si_cp");

    model.component("comp1").physics().create("ht", "HeatTransfer", "geom1");
    model.component("comp1").physics("ht").prop("ShapeProperty").set("order_temperature", 2);
    model.component("comp1").physics("ht").feature("init1").set("Tinit", "Tamb");
    model.component("comp1").physics("ht").create("hs1", "HeatSource", 3);
    model.component("comp1").physics("ht").feature("hs1").selection().all();
    model.component("comp1").physics("ht").feature("hs1").set("Q0", "qSi");
    model.component("comp1").physics("ht").create("hf1", "HeatFluxBoundary", 2);
    model.component("comp1").physics("ht").feature("hf1").selection().named("top");
    model.component("comp1").physics("ht").feature("hf1").set("HeatFluxType", "ConvectiveHeatFlux");
    model.component("comp1").physics("ht").feature("hf1").set("h", "hTop");
    model.component("comp1").physics("ht").feature("hf1").set("Text", "Tamb");

    model.component("comp1").mesh().create("mesh1");
    model.component("comp1").mesh("mesh1").create("map1", "Map");
    model.component("comp1").mesh("mesh1").feature("map1").selection().named("bottom");
    model.component("comp1").mesh("mesh1").feature("map1").create("dist1", "Distribution");
    model.component("comp1").mesh("mesh1").feature("map1").feature("dist1").selection().named("bottomEdges");
    model.component("comp1").mesh("mesh1").feature("map1").feature("dist1").set("numelem", 2);
    model.component("comp1").mesh("mesh1").feature("map1").feature("dist1").set("equidistant", true);
    model.component("comp1").mesh("mesh1").create("swe1", "Sweep");
    model.component("comp1").mesh("mesh1").feature("swe1").selection().geom(3);
    model.component("comp1").mesh("mesh1").feature("swe1").selection().all();
    model.component("comp1").mesh("mesh1").feature("swe1").selection("sourceface").geom(2);
    model.component("comp1").mesh("mesh1").feature("swe1").selection("sourceface").set(3);
    model.component("comp1").mesh("mesh1").feature("swe1").selection("targetface").geom(2);
    model.component("comp1").mesh("mesh1").feature("swe1").selection("targetface").set(4);
    model.component("comp1").mesh("mesh1").feature("swe1").create("dist1", "Distribution");
    model.component("comp1").mesh("mesh1").feature("swe1").feature("dist1").set("numelem", 8);
    model.component("comp1").mesh("mesh1").run();

    model.study().create("std1");
    model.study("std1").create("stat", "Stationary");

    model.sol().create("sol1");
    model.sol("sol1").study("std1");
    model.sol("sol1").create("st1", "StudyStep");
    model.sol("sol1").feature("st1").set("study", "std1");
    model.sol("sol1").feature("st1").set("studystep", "stat");
    model.sol("sol1").create("v1", "Variables");
    model.sol("sol1").create("s1", "Stationary");
    model.sol("sol1").feature("s1").set("nonlin", "off");
    model.sol("sol1").feature("s1").feature("dDef").set("linsolver", "pardiso");
    model.sol("sol1").attach("std1");
    model.sol("sol1").runAll();
    model.sol("sol1").getU();

    model.result().dataset().create("solData", "Solution");
    model.result().dataset("solData").set("solution", "sol1");
    model.result().numerical().create("sampleT", "Interp");
    model.result().numerical("sampleT").set("data", "solData");
    model.result().numerical("sampleT").set("expr", new String[]{"T"});
    model.result().numerical("sampleT").set("unit", "K");
    model.result().numerical("sampleT").set("ext", 0);
    model.result().numerical("sampleT").selection().all();
    model.result().numerical().create("qin", "IntVolume");
    model.result().numerical("qin").set("data", "solData");
    model.result().numerical("qin").selection().all();
    model.result().numerical("qin").set("expr", new String[]{"qSi", "1"});
    model.result().numerical().create("qout", "IntSurface");
    model.result().numerical("qout").set("data", "solData");
    model.result().numerical("qout").selection().named("top");
    model.result().numerical("qout")
         .set("expr", new String[]{"hTop*(T-Tamb)", "1", "T", "-si_k*(nx*Tx+ny*Ty+nz*Tz)"});
    model.result().create("pg1", "PlotGroup3D");
    model.result("pg1").set("data", "solData");
    model.result("pg1").create("surf1", "Surface");
    model.result("pg1").feature("surf1").set("expr", "T");

    return model;
  }

  public static void main(String[] args) {
    run();
  }

}
