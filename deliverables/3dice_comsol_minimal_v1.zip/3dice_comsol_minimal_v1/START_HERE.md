# 先做 H0

请打开 [COMSOL 操作任务单](docs/COMSOL_TASK.md)，从“本次先做什么”开始。

本包已有真实 3D-ICE 结果，COMSOL 需在你的电脑上按步骤建模运行。没有预生成 .mph。参数是独立验证算例定义，不是 TAP 已采用参数。

优先目录：outputs/minimal_coupon_v1/h0_z16/
